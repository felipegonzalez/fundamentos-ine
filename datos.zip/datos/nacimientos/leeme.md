
- Datos extraidos de https://www.inegi.org.mx/programas/natalidad/?ps=Microdatos
- Ver script de preprocesamiento preprocesamiento_natalidad.R


